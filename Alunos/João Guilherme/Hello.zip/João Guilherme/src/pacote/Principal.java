package pacote;

import java.util.ArrayList;
import java.util.Scanner;

public class Principal {
	private static ArrayList<Usuarios> usuarios = new ArrayList<>();
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int opcao;
		
		do {
			System.out.println("\nMenu");
			System.out.println("1. Cadastrar usuário");
			System.out.println("2. Listar usuários");
			System.out.println("3. Excluir usuário");
			System.out.println("4. Listar por ordem de idade");
			System.out.println("5. Sair");
			opcao = scan.nextInt();
			
			switch(opcao) {
			case 1:
				cadastrarUsuario(scan);
				break;
			case 2:
				listarUsuarios();
				break;
			case 3:
				excluirUsuario(scan);
				break;
			case 4:
				listarPorIdade();
				break;
			default: 
				System.out.println("Opção inválida");
			}
		}while(opcao != 5);
		scan.close();
	}

	public static void cadastrarUsuario(Scanner scan) {
		System.out.println("digite seu nome: ");
		String nome = scan.next();
		System.out.println("digite seu nome: ");
		int idade = scan.nextInt();
		System.out.println("Cadastrado com sucesso!!!");
		Usuarios usuario = new Usuarios(nome, idade);
		//scan.nextLine();
		usuarios.add(usuario);
	}
	public static void listarUsuarios() {
		for(Usuarios pessoa : usuarios) {
			System.out.print("Nome: " + pessoa.getNome() + "Idade: " + pessoa.getIdade());
		}
	}
	public static void excluirUsuario(Scanner scan) {
		System.out.println("qual usuario deseja excluir");
		String nome = scan.nextLine();
		boolean usuarioEncontrado = false;
		for(int i = 0; i < usuarios.size(); i++) {
			if(usuarios.get(i).getNome().equalsIgnoreCase(nome)) {
				usuarios.remove(i);
				usuarioEncontrado = true;
				System.out.println("Usuario removido");
				break;
			}
		}
	}
	public static void listarPorIdade() {
		if(usuarios.isEmpty()) {
			System.out.println("Lista vazia");
			return;
		}else {
			for (int i = 0; i < usuarios.size() - 1; i++) {
				for (int j = 0; j <usuarios.size() - i; j++) {
					if(usuarios.get(j).getIdade()>usuarios.get(j+1).getIdade()) {
						
					}
				}	
			}
		}
	}
}
